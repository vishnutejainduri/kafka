const sdkMiddlewareAuth = {
  createAuthMiddlewareForClientCredentialsFlow: () => ({})
};

module.exports = sdkMiddlewareAuth;
