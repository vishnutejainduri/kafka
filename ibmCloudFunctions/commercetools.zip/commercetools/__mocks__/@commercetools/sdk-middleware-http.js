const sdkMiddlewareHttp = {
  createHttpMiddleware: () => ({})
};

module.exports = sdkMiddlewareHttp;
